import 'package:baking_house/model/user.model.dart';

class UserDataBase {
  List<User> users = [User
  (name: "l", 
   password: "l")
  ];
}